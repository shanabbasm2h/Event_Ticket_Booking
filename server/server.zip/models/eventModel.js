import mongoose from "mongoose";

const eventSchema = new mongoose.Schema({
  name: String,
  price: Number,
  location: String,
  image: String,
  bookedSeats: { type: Number, default: 0 },
  availableSeats: { type: Number, default: 80 },
  seats: {
    type: [[Number]],
    default: [
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    ],
  },
});

const Event = mongoose.model("Event", eventSchema);

export default Event;
